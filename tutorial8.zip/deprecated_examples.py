# Deprecated API v1 functions

# vrCamera
addViewPoint("New Viewpoint")

vrCameraService.createViewpoint('New Viewpoint')

# vrOSGWidget
createBackplate('filePath')
setBackplate('filePath')
deleteBackplate()

vrSceneplateService.createNode()  # TODO Parameter prüfen

# vrRenerSettings
setRaytracingAAThreshold()